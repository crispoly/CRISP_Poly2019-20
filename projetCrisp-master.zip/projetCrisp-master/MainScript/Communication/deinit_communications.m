function [ ] = deinit_communications( )
%deinit_communications D�-initialisation de la communication.
%   Rien � faire � date...

global commBot;

delete(commBot);

end

