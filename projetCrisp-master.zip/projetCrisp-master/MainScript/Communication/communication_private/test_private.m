function [ out1 ] = test_private( in1 )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
out1 = 1;

end

