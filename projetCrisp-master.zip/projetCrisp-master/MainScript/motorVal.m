
global motPect motDelt;

motPect = struct;
motPect.maxSpeed = 1000;
motPect.maxTorque = 10000;
motPect.minPos = 0;
motPect.maxPos = 100;
motPect.adress = 2;

motDelt = struct;
motDelt.maxSpeed = 2000;
motDelt.maxTorque = 1500;
motDelt.minPos = 0;
motDelt.maxPos = 1000;
motDelt.adress = 3;
