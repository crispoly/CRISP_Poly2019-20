% Copyright (C) 1993-2017, by Peter I. Corke
%
% This file is part of The Robotics Toolbox for MATLAB (RTB).
% 
% RTB is free software: you can redistribute it and/or modify
% it under the terms of the GNU Lesser General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% RTB is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU Lesser General Public License for more details.
% 
% You should have received a copy of the GNU Leser General Public License
% along with RTB.  If not, see <http://www.gnu.org/licenses/>.
%
% http://www.petercorke.com

%%begin

% A quadrotor is a simple flying vehicle with 4 propellers with their thrust
% axes pointing upwards.  This demo shows an animation of a flying quadrotor
% with a nested control system.

% We can open a Simulink model of the quadrotor and its controller.
sl_quadrotor

% Running the simulation shows the vehicle takes off and flying in a cirle.
sim('sl_quadrotor');
