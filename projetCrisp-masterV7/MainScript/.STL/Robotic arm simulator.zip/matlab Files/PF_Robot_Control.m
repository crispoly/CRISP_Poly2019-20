%==========================================================================
% >>>>>>>>>>>>>>>>> FUNCTION PF-G.1: ROBOT CONTROL SYSTEM <<<<<<<<<<<<<<<<<
%==========================================================================
% Created by Diego Varalda de Almeida
% Date: March 30th, 2016.

% Description: This function will implement the control system for
% controlling the manipulator. Refer to section 4 of documentation for
% details.
%==========================================================================
function PF_Robot_Control()

end