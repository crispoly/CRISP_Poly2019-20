%==========================================================================
% >>>>>>>>>>>>> FUNCTION SF-9: REPEAT COMMANDS IN HISTORY <<<<<<<<<<<<<<<
%==========================================================================
% Created by Diego Varalda de Almeida
% version 2.0 - March 30th, 2016.

% DESCRIPTION: This function will receive the user inputs from GUI (command
% numbers) and copy those from history
% . Refer to section 4 of documentation for details.
%==========================================================================
function SF_Repeat_Commands(In)
% In.cn = command number (a scalar or a vector with the commands to copy
% from history);





end